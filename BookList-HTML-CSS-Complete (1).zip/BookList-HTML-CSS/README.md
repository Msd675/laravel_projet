# BookList - HTML/CSS Version

Application web de gestion de bibliothèque personnelle en HTML/CSS classique (sans framework).

## 📁 Structure des fichiers

```
BookList-HTML-CSS/
├── index.html          # Page d'accueil
├── about.html          # Page À propos
├── contact.html        # Page Contact avec formulaire
├── login.html          # Page de connexion
├── dashboard.html      # Dashboard privé
├── styles.css          # Styles globaux
└── README.md           # Documentation
```

## 🎯 Pages incluses

### 1. **index.html** - Page d'accueil
- Hero section percutante
- Section fonctionnalités
- Section équipe
- Footer complet
- Navigation sticky

### 2. **about.html** - À propos
- Mission et vision
- Caractéristiques principales
- Technologies utilisées
- CTA (Call To Action)

### 3. **contact.html** - Contact
- Formulaire de contact (Nom, Email, Message)
- Informations de contact
- Validation de formulaire
- Messages de succès/erreur

### 4. **login.html** - Connexion
- Formulaire de connexion
- Options OAuth (Google, GitHub)
- Lien vers inscription
- Design épuré

### 5. **dashboard.html** - Dashboard
- Sidebar de navigation
- Indicateurs statistiques (À lire, En cours, Terminé)
- Liste des livres
- Actions CRUD (Modifier, Supprimer)
- Recherche et filtres

## 🎨 Design System

### Couleurs
```css
--color-primary: #2563eb (Bleu)
--color-success: #10b981 (Vert)
--color-warning: #f59e0b (Orange)
--color-danger: #ef4444 (Rouge)
```

### Typographie
- Font: System fonts (Apple System, Segoe UI, Roboto)
- Tailles: xs (0.75rem) à 6xl (3.75rem)
- Poids: normal, medium, semibold, bold

### Espacements
- xs: 0.25rem
- sm: 0.5rem
- md: 1rem
- lg: 1.5rem
- xl: 2rem
- 2xl: 3rem
- 3xl: 4rem

### Rayons de bordure
- sm: 0.375rem
- md: 0.5rem
- lg: 0.75rem
- xl: 1rem
- 2xl: 1.5rem

## 🚀 Utilisation

### Installation
1. Téléchargez tous les fichiers
2. Placez-les dans un dossier
3. Ouvrez `index.html` dans votre navigateur

### Serveur local (optionnel)
```bash
# Avec Python 3
python -m http.server 8000

# Avec Node.js (http-server)
npx http-server
```

Puis accédez à `http://localhost:8000`

## 📱 Responsive Design

L'application est entièrement responsive :
- **Mobile** : < 480px
- **Tablet** : 480px - 768px
- **Desktop** : > 768px

## ✨ Fonctionnalités

### Pages publiques
- ✅ Navigation sticky
- ✅ Hero section animée
- ✅ Grilles responsives
- ✅ Formulaire de contact
- ✅ Footer complet

### Pages privées
- ✅ Sidebar de navigation
- ✅ Indicateurs statistiques
- ✅ Liste des livres
- ✅ Actions CRUD
- ✅ Recherche et filtres

### Interactions
- ✅ Hover effects
- ✅ Focus states
- ✅ Animations subtiles
- ✅ Validation de formulaire
- ✅ Messages de feedback

## 🔧 Personnalisation

### Modifier les couleurs
Éditez les variables CSS dans `styles.css` :
```css
:root {
    --color-primary: #2563eb; /* Changez cette valeur */
    --color-secondary: #64748b;
    /* ... */
}
```

### Modifier la typographie
```css
:root {
    --font-family: 'Votre police', sans-serif;
    --font-size-base: 1rem;
    /* ... */
}
```

### Ajouter des pages
1. Créez un nouveau fichier `.html`
2. Copiez la structure de base d'une page existante
3. Importez `styles.css`
4. Ajoutez le lien dans la navigation

## 📝 Notes importantes

- **Pas de dépendances** : Pur HTML/CSS/JavaScript vanilla
- **Pas de build** : Fonctionne directement dans le navigateur
- **Léger** : ~50KB au total (HTML + CSS)
- **Compatible** : Tous les navigateurs modernes

## 🔐 Sécurité

Pour une application en production :
- Validez les formulaires côté serveur
- Utilisez HTTPS
- Implémentez l'authentification OAuth
- Protégez les données sensibles

## 📞 Support

Pour toute question ou suggestion, consultez la documentation ou contactez l'équipe.

---

**Version** : 1.0  
**Dernière mise à jour** : 2026  
**Licence** : MIT
